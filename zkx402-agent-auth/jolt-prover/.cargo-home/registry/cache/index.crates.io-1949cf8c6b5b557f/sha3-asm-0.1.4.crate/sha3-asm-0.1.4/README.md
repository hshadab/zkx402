# sha3-asm

Raw bindings for SHA-3 algorithms written in assembly.

This crate is not intended for direct use, most users should prefer the [`keccak-asm`] crate.

[`keccak-asm`]: https://docs.rs/keccak-asm

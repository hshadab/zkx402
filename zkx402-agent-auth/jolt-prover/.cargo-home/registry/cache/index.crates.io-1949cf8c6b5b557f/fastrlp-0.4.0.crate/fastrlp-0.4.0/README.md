# fastrlp
Very fast and well-tested RLP serialization library for Rust.

## License
The entire code within this repository is licensed under the [Mozilla Public License v2.0](./LICENSE)

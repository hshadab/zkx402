# `semver-parser`

~~Parsing for the semver spec.~~

~~We'll have better docs at 1.0.~~

Originally intended to be a way to just parse the semver spec into data structures, with no logic around matching and such, this functionality now lives in the semver crate, and therefore, is no longer used.
